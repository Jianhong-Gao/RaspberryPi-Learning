from py_package_so.sa import say_hello

say_hello('JIANHONG')